module.exports = {
  config: {
    name: "war",
    aliases: ["chud"],
    version: "1.0",
    author: "nexo_here",
    role: 2,
    category: "admin",
    guide: {
      vi: "Not Available",
      en: "chud @(mention)"
    } 
  },

  onStart: async function ({ api, event, userData, args }) {
      var mention = Object.keys(event.mentions)[0];
    if(!mention) return api.sendMessage("Need to tag 1 friend whome you want to scold with bad words", event.threadID);
 let name =  event.mentions[mention];
    var arraytag = []; 
        arraytag.push({id: mention, tag: name});
    var a = function (a) { api.sendMessage(a, event.threadID); }
setTimeout(() => {a({body: "কিরে মাদারচোত নেওয়াজ এর চুদন খাওয়ায় জন্য রেডি তো?" + "লে চুদা খা মাঙ্গের বেটা 😂😂" + name, mentions: arraytag})}, 3000);
setTimeout(() => {a({body: "মাঘি চুদা শরের বাচ্চা কার লগে পঙ্গা নিতে আসছিস 🤬🤬🤬" + " " + name, mentions: arraytag})}, 5000);
setTimeout(() => {a({body: " চুদে গুহা ফাঁক করে দিব খানকীর পোলা 🤤" + " " + name, mentions: arraytag})}, 7000);
setTimeout(() => {a({body: " মাদারচোত বোকাচোদা খানকীর পোলা " + " " + name, mentions: arraytag})}, 9000);
setTimeout(() => {a({body: " বেসসা মাঘী চোদা কুত্তা চোদা" + " " + name, mentions: arraytag})}, 12000);
setTimeout(() => {a({body: " ছাগল চুদা গরু চুদা মাঙ্গের বেটা লোকজন দেখে লাগতে আসিস কুত্তার বাচ্চা 🤬" + " " + name, mentions: arraytag})}, 14000);
setTimeout(() => {a({body: " তোর আব্বুকে ভুলে গেলি মাদারচোত 😂" + " " + name, mentions: arraytag})}, 16000);
setTimeout(() => {a({body: " তোকে কনডম ছাড়া চুদী মঙ্গের বেটা 🖕🏿" + " " + name, mentions: arraytag})}, 18000);
setTimeout(() => {a({body: " আমার ধন চুষ তাইলে থামবো 😂" + " " + name, mentions: arraytag})}, 20000);
setTimeout(() => {a({body: " তোরে কুত্তা দিয়ে চোদাই 😍" + " " + name, mentions: arraytag})}, 22000);
setTimeout(() => {a({body: " মাঘীর মাং চাটিস বোকাচোদার বাচ্চা তোকে কন্ডম ছাড়া উল্টা করে চুদি 🤬" + " " + name, mentions: arraytag})}, 2400);
setTimeout(() => {a({body: " এখনো সময় আছে মাফ চা 🤣🤣" + " " + name, mentions: arraytag})}, 26000);
setTimeout(() => {a({body: " তোর নানি কেমন আছে 😍??" + " " + name, mentions: arraytag})}, 28000);
setTimeout(() => {a({body: " তোকে চুদী 🥰" + " " + name, mentions: arraytag})}, 30000);
setTimeout(() => {a({body: " মাদারচোত 🥰" + " " + name, mentions: arraytag})}, 32000);
setTimeout(() => {a({body: " আব্বা কে ভুলিস না 🤬" + " " + name, mentions: arraytag})}, 65000);
setTimeout(() => {a({body: " আজকের চুদন আজীবন মনে রাখিস বোকাচোদা 🤣🤣🤣" + " " + name, mentions: arraytag})}, 34000);
setTimeout(() => {a({body: "মাঘা 🥰" + " " + name, mentions: arraytag})}, 36000);
setTimeout(() => {a({body: " আয় আমার হোল টা চুষে দে 🥵🥵" + " " + name, mentions: arraytag})}, 38000);
setTimeout(() => {a({body: " বাপ কে ভুলিস না বোকাচোদার বাচ্চা 🤬🤬🤬🤬🤬" + " " + name, mentions: arraytag})}, 40000);
setTimeout(() => {a({body: " হোল কাটে নিবো 🤬🤬🤬🤬🤬🤬" + " " + name, mentions: arraytag})}, 44000);
setTimeout(() => {a({body: " তোমার গুষ্টি চুদী ব্রো 😞🖕🏿" + " " + name, mentions: arraytag})}, 460000);
setTimeout(() => {a({body: "🖕🏿🖕🏿🖕🏿🖕🏿🖕🏿🖕🏿🖕🏿🖕🏿🖕🏿" + " " + name, mentions: arraytag})}, 48000);
setTimeout(() => {a({body: " মাঘীর ছেলে তোর মাকে চুদী 🖕🏽🖕🏽🖕🏽 " + " " + name, mentions: arraytag})} , 50000);
setTimeout(() => {a({body: " আজকে তোকে প্যান্ট না খুলেই চুদবো 🤬 তোর মাকে একটু আগেই চুঁদে আসলাম 😂" + " " + name, mentions: arraytag})} , 52000);
setTimeout(() => {a({body: "বোকাচোদার বাচ্চা 😂" + " " + name, mentions: arraytag})} , 56000);
setTimeout(() => {a({body: " মাদারচোত বোকাচোদা খানকীর ছেলে 🤬" + " " + name, mentions: arraytag})} , 58000);
setTimeout(() => {a({body: " প্যান্ট ভিজে নাই 🤣🤣🤣🤣🤣🤣🤣???" + " " + name, mentions: arraytag})} , 60000);
setTimeout(() => {a({body: " আরো চুদন খাইতে চাচ্ছিস ???? " + " " + name, mentions: arraytag})} , 62000);
setTimeout(() => {a({body: " আয় মাদারচোত আমার ধণ টা চুষে যা 🤬"+ " " + name, mentions: arraytag})} , 64000);
setTimeout(() => {a({body: " তোকে ডগি স্টাইল e চুদী 😋😋" + " " + name, mentions: arraytag})} , 66000);
setTimeout(() => {a({body: " তোর আব্বাকে ভুললে আরেকবার এমন চুদন চুদবো মোর যাবি মঙ্গের বেটা 😂😂😂" + " " + name, mentions: arraytag})} , 68000);
setTimeout(() => {a({body: " আজকের চুদন আজীবন মনে রাখবি 🤣🤣🤣" + " " + name, mentions: arraytag})} , 70000);
setTimeout(() => {a({body: " আয় আমার ধোন টা চুষে যা মঙ্গের পুত 🤬🤬🤬🤬" + " " + name, mentions: arraytag})} , 72000);
setTimeout(() => {a({body: " তোরে মুততে মুততে চুদী 🤣🤣" + " " + name, mentions: arraytag})} , 74000);
setTimeout(() => {a({body: " চুঁদে পাউরুটি বানায় তোর হোগায় ভরে দিব মাঙ্গের বেতা চিনিস আমারে???" + " " + name, mentions: arraytag})} , 76000);
setTimeout(() => {a({body: " খানকীর পোলা তোর বাপকে ভুলে গেলি?? জন্ম দেওয়া ভুল হইলো 🤬🤬🤬" + " " + name, mentions: arraytag})} , 78000);
setTimeout(() => {a({body: "বোকাচোদার বাচ্চা 😍" + " " + name, mentions: arraytag})} , 80000);
setTimeout(() => {a({body: " তোকে চুদী 😍😍😍" + " " + name, mentions: arraytag})} , 82000);
setTimeout(() => {a({body: " হোল কাটে নিবো মঙ্গের বেটা কার লগে লাগতে আসছিস 🤬" + " " + name, mentions: arraytag})} , 84000);
setTimeout(() => {a({body: "নেওয়াজ এর চুদন কেমন লাগলো বাচ্চা 🤣🤣🤣🤣??" + " " + name, mentions: arraytag})} , 84000);
  }
};
