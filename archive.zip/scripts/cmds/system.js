module.exports = {
  config: {
    name: "system",
    aliases: ["sysinfo"],
    version: "2.0",
    author: "Rahez Gemini",
    shortDescription: "Display complete system information",
    longDescription: "Shows detailed system information including hardware, memory, and bot stats",
    category: "system",
    guide: "{pn}"
  },

  onStart: async function({ message }) {
    try {
      const os = require('os');
      const process = require('process');
      const v8 = require('v8');
      
      // System Information
      const platform = os.platform();
      const arch = os.arch();
      const hostname = os.hostname();
      const release = os.release();
      
      // CPU Information
      const cpus = os.cpus();
      const cpuModel = cpus[0].model;
      const cpuCores = cpus.length;
      const cpuSpeed = `${cpus[0].speed}MHz`;
      
      // Memory Information
      const totalMem = (os.totalmem() / (1024 ** 3)).toFixed(2);
      const freeMem = (os.freemem() / (1024 ** 3)).toFixed(2);
      const usedMem = (os.totalmem() - os.freemem()) / (1024 ** 3).toFixed(2);
      
      // Bot Process Information
      const uptime = formatUptime(process.uptime());
      const nodeVersion = process.version;
      const pid = process.pid;
      const heapStats = v8.getHeapStatistics();
      
      // Network Information
      const networkInterfaces = os.networkInterfaces();
      let ipAddresses = [];
      Object.keys(networkInterfaces).forEach(iface => {
        networkInterfaces[iface].forEach(addr => {
          if (addr.family === 'IPv4' && !addr.internal) {
            ipAddresses.push(addr.address);
          }
        });
      });
      
      // Prepare the message
      const sysInfo = `
🖥️ SYSTEM INFORMATION:

[PLATFORM]
• OS: ${platform} ${arch}
• Hostname: ${hostname}
• Kernel: ${release}
• IP Addresses: ${ipAddresses.join(', ') || 'N/A'}

[PROCESSOR]
• Model: ${cpuModel}
• Cores: ${cpuCores}
• Speed: ${cpuSpeed}

[MEMORY]
• Total: ${totalMem} GB
• Used: ${usedMem} GB
• Free: ${freeMem} GB

[BOT PROCESS]
• Uptime: ${uptime}
• Node.js: ${nodeVersion}
• PID: ${pid}
• Heap Total: ${(heapStats.total_heap_size / (1024 ** 2)).toFixed(2)} MB
• Heap Used: ${(heapStats.used_heap_size / (1024 ** 2)).toFixed(2)} MB
      `.trim();
      
      message.reply(sysInfo);
    } catch (error) {
      console.error('System command error:', error);
      message.reply('❌ Failed to retrieve system information');
    }
  }
};

function formatUptime(seconds) {
  const days = Math.floor(seconds / (3600 * 24));
  seconds %= 3600 * 24;
  const hours = Math.floor(seconds / 3600);
  seconds %= 3600;
  const minutes = Math.floor(seconds / 60);
  seconds = Math.floor(seconds % 60);
  
  return `${days}d ${hours}h ${minutes}m ${seconds}s`;
}