const { GoogleGenerativeAI } = require("@google/generative-ai");

module.exports = {
  config: {
    name: "gemini",
    aliases: ["ai", "ask"],
    version: "2.0",
    author: "𝙍𝙖𝙝𝙚𝙯 𝙂𝙚𝙢𝙞𝙣𝙞",
    shortDescription: "Chat with Gemini AI",
    longDescription: "Ask questions and get responses from Google's Gemini AI (1.5 Flash model)",
    category: "AI",
    guide: "{pn} [your question]"
  },

  onStart: async function({ message, args }) {
    try {
      const prompt = args.join(" ");
      if (!prompt) return message.reply("Please provide a question.");

      // Initialize the Gemini API
      const genAI = new GoogleGenerativeAI("AIzaSyBb6VcZZ9bioWCo1NL09MXwh4rck7neIg8");
      const model = genAI.getGenerativeModel({ model: "gemini-2.0-flashh });

      // Start a chat session
      const chat = model.startChat({
        history: [
          {
            role: "user",
            parts: [{ text: "You are a helpful AI assistant. Respond concisely and helpfully." }]
          },
          {
            role: "model",
            parts: [{ text: "Understood! I'll provide concise and helpful responses." }]
          }
        ],
        generationConfig: {
          maxOutputTokens: 1000,
          temperature: 0.9,
          topP: 0.1
        }
      });

      // Send message and get response
      const result = await chat.sendMessage(prompt);
      const response = await result.response;
      const text = response.text();

      // Send the response back
      await message.reply(text);
    } catch (error) {
      console.error("Gemini Error:", error);
      message.reply("❌ An error occurred while processing your request.");
    }
  }
};